﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Laptop_detail
{
    public partial class Laptop : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Tanmay\Documents\Laptop.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");

        public Laptop()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Laptop_Load(object sender, EventArgs e)
        {
            Display();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox1.Clear();
            textBox4.Text = "";
            textBox5.Clear();
            comboBox1.SelectedIndex = -1;
            textBox1.Focus();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"INSERT INTO Details
                         (Model, Rating, Ram, OS, Weight, Screen_Size)
VALUES        ('" + textBox1.Text + "','" + comboBox1.Text + "','" + textBox4.Text + "','" + textBox2.Text + "','" + textBox5.Text + "','" + textBox6.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Succes..!!");
            Display();

        }
        void Display()
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Details", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["Model"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["Rating"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["Ram"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["OS"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["Weight"].ToString();
                dataGridView1.Rows[n].Cells[5].Value = item["Screen_Size"].ToString();

            }

        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            textBox6.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"UPDATE       Details
SET                Model ='"+textBox1.Text+"', Rating ='"+comboBox1.Text+"', Ram ='"+textBox4.Text+"', OS ='"+textBox2.Text+"', Weight ='"+textBox5.Text+"', Screen_Size ='"+textBox6.Text+"' WHERE (Model = '"+textBox1.Text+"')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("updated Succes..!!");
            Display();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"DELETE FROM Details
WHERE        (Model = '" + textBox1.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("deleted Succes..!!");
            Display();
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

            SqlDataAdapter sda = new SqlDataAdapter("Select * from Details WHERE (Model like '%" + textBox3.Text + "%') or (Rating like '%" + textBox3.Text + "%') or (Ram like '%" + textBox3.Text + "%') or (OS like '%" + textBox3.Text + "%') or (Weight like '%" + textBox3.Text + "%') or (Screen_Size like '%" + textBox3.Text + "%')", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["Model"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["Rating"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["Ram"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["OS"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["Weight"].ToString();
                dataGridView1.Rows[n].Cells[5].Value = item["Screen_Size"].ToString();

            }
        }
    }
}